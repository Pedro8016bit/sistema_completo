﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using K4os.Compression.LZ4.Streams.Internal;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Sistema_completo
{
    internal class Produtos
    {
        private string nome_produto;
        private string preco_produto;
        private string quantidade;
        private string categoria;

        public string Nome_produto
        {
            get { return nome_produto; }
            set { nome_produto = value; }
        }
        public string Preco
        {
            get { return preco_produto; }
            set { preco_produto = value; }
        }
        public string Quantidade
        {
            get { return quantidade;}
            set { quantidade = value;}
        }
        public string Categoria
        {
            get { return categoria;}
            set { categoria = value; }
        }

        public bool Inserir_produtos()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new BancoDb().Conectar())
                {
                    if (ProdutoExiste())
                    {
                        MessageBox.Show("Esse produto ja existe no sistema");
                        return false;
                    }
                    else
                    {
                        string inserir = "insert into produtos (nome, preco, quantidade, categoria) values (@nome, @preco, @quantidade, @categoria);";

                        MySqlCommand comando = new MySqlCommand(inserir, conexaoBanco);
                        comando.Parameters.AddWithValue("@nome", Nome_produto);
                        comando.Parameters.AddWithValue("@preco", Preco);
                        comando.Parameters.AddWithValue("@quantidade", Quantidade);
                        comando.Parameters.AddWithValue("@categoria", Categoria);

                        int resultado = comando.ExecuteNonQuery();

                        if (resultado > 0)
                        {
                            return true;
                            MessageBox.Show("Produto cadastrado com sucesso!!");
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("erro ao cadastrar produto" + ex.Message);
                return false;
            }
        }

        public bool ProdutoExiste()
        {
            try
            {
                using (MySqlConnection conexao = new BancoDb().Conectar())
                {
                    string query = "SELECT COUNT(*) FROM produtos WHERE nome = @nome";
                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    comando.Parameters.AddWithValue("@nome", Nome_produto);

                    long resultado = (long)comando.ExecuteScalar();
                    if (resultado > 0)
                    {
                        return true;

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao verificar existência do produto: " + ex.Message);
                return false;
            }
            return false;
        }

        public bool EditarProduto(int idProduto, string nome, int quantidade, decimal preco, int categoria)
        {
            try
            {
                using (MySqlConnection conexao = new BancoDb().Conectar())
                {
                    string query = "UPDATE produtos SET nome = @nome, quantidade = @quantidade, preco = @preco, categoria = @categoria WHERE id_produto = @id";

                    MySqlCommand comando = new MySqlCommand(query, conexao);
                    comando.Parameters.AddWithValue("@nome", nome);
                    comando.Parameters.AddWithValue("@quantidade", quantidade);
                    comando.Parameters.AddWithValue("@preco", preco);
                    comando.Parameters.AddWithValue("@categoria", categoria);
                    comando.Parameters.AddWithValue("@id", idProduto);

                    int linhasAfetadas = comando.ExecuteNonQuery();

                    if(linhasAfetadas > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao editar o produto: " + ex.Message);
                return false;
            }
        }

    }
}
