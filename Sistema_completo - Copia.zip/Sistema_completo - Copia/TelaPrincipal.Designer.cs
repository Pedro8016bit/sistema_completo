﻿namespace Sistema_completo
{
    partial class TelaPrincipal
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txt_pesquisar = new TextBox();
            cmb_categoria1 = new ComboBox();
            dataGrid = new DataGridView();
            cmb_categoria2 = new ComboBox();
            txt_nome_produto = new TextBox();
            txt_quantidade = new NumericUpDown();
            txt_preco = new TextBox();
            btn_adicionar = new Button();
            btn_editar = new Button();
            btn_excluir = new Button();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            btn_pesquisa = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGrid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)txt_quantidade).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(17, 39);
            label1.Name = "label1";
            label1.Size = new Size(60, 15);
            label1.TabIndex = 0;
            label1.Text = "Pesquisar:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(17, 73);
            label2.Name = "label2";
            label2.Size = new Size(61, 15);
            label2.TabIndex = 0;
            label2.Text = "Categoria:";
            // 
            // txt_pesquisar
            // 
            txt_pesquisar.Location = new Point(83, 36);
            txt_pesquisar.Name = "txt_pesquisar";
            txt_pesquisar.Size = new Size(269, 23);
            txt_pesquisar.TabIndex = 1;
            // 
            // cmb_categoria1
            // 
            cmb_categoria1.FormattingEnabled = true;
            cmb_categoria1.Location = new Point(83, 70);
            cmb_categoria1.Name = "cmb_categoria1";
            cmb_categoria1.Size = new Size(121, 23);
            cmb_categoria1.TabIndex = 2;
            // 
            // dataGrid
            // 
            dataGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGrid.Location = new Point(17, 102);
            dataGrid.Name = "dataGrid";
            dataGrid.Size = new Size(429, 313);
            dataGrid.TabIndex = 3;
            // 
            // cmb_categoria2
            // 
            cmb_categoria2.FormattingEnabled = true;
            cmb_categoria2.Location = new Point(648, 195);
            cmb_categoria2.Name = "cmb_categoria2";
            cmb_categoria2.Size = new Size(128, 23);
            cmb_categoria2.TabIndex = 4;
            // 
            // txt_nome_produto
            // 
            txt_nome_produto.Location = new Point(483, 134);
            txt_nome_produto.Name = "txt_nome_produto";
            txt_nome_produto.Size = new Size(128, 23);
            txt_nome_produto.TabIndex = 5;
            // 
            // txt_quantidade
            // 
            txt_quantidade.Location = new Point(648, 134);
            txt_quantidade.Name = "txt_quantidade";
            txt_quantidade.Size = new Size(128, 23);
            txt_quantidade.TabIndex = 6;
            // 
            // txt_preco
            // 
            txt_preco.Location = new Point(483, 195);
            txt_preco.Name = "txt_preco";
            txt_preco.Size = new Size(128, 23);
            txt_preco.TabIndex = 7;
            // 
            // btn_adicionar
            // 
            btn_adicionar.Location = new Point(483, 297);
            btn_adicionar.Name = "btn_adicionar";
            btn_adicionar.Size = new Size(75, 23);
            btn_adicionar.TabIndex = 8;
            btn_adicionar.Text = "Adicionar";
            btn_adicionar.UseVisualStyleBackColor = true;
            btn_adicionar.Click += btn_adicionar_Click;
            // 
            // btn_editar
            // 
            btn_editar.Location = new Point(593, 297);
            btn_editar.Name = "btn_editar";
            btn_editar.Size = new Size(75, 23);
            btn_editar.TabIndex = 9;
            btn_editar.Text = "Editar";
            btn_editar.UseVisualStyleBackColor = true;
            // 
            // btn_excluir
            // 
            btn_excluir.Location = new Point(701, 297);
            btn_excluir.Name = "btn_excluir";
            btn_excluir.Size = new Size(75, 23);
            btn_excluir.TabIndex = 10;
            btn_excluir.Text = "Excluir";
            btn_excluir.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(483, 116);
            label3.Name = "label3";
            label3.Size = new Size(43, 15);
            label3.TabIndex = 11;
            label3.Text = "Nome:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(648, 116);
            label4.Name = "label4";
            label4.Size = new Size(72, 15);
            label4.TabIndex = 12;
            label4.Text = "Quantidade:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(482, 179);
            label5.Name = "label5";
            label5.Size = new Size(40, 15);
            label5.TabIndex = 13;
            label5.Text = "Preço:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(647, 177);
            label6.Name = "label6";
            label6.Size = new Size(58, 15);
            label6.TabIndex = 14;
            label6.Text = "Categoria";
            // 
            // btn_pesquisa
            // 
            btn_pesquisa.Location = new Point(270, 69);
            btn_pesquisa.Name = "btn_pesquisa";
            btn_pesquisa.Size = new Size(82, 23);
            btn_pesquisa.TabIndex = 15;
            btn_pesquisa.Text = "Pesquisar";
            btn_pesquisa.UseVisualStyleBackColor = true;
            // 
            // TelaPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(btn_pesquisa);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(btn_excluir);
            Controls.Add(btn_editar);
            Controls.Add(btn_adicionar);
            Controls.Add(txt_preco);
            Controls.Add(txt_quantidade);
            Controls.Add(txt_nome_produto);
            Controls.Add(cmb_categoria2);
            Controls.Add(dataGrid);
            Controls.Add(cmb_categoria1);
            Controls.Add(txt_pesquisar);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "TelaPrincipal";
            Size = new Size(850, 430);
            Load += TelaPrincipal_Load;
            ((System.ComponentModel.ISupportInitialize)dataGrid).EndInit();
            ((System.ComponentModel.ISupportInitialize)txt_quantidade).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txt_pesquisar;
        private ComboBox cmb_categoria1;
        private DataGridView dataGrid;
        private ComboBox cmb_categoria2;
        private TextBox txt_nome_produto;
        private NumericUpDown txt_quantidade;
        private TextBox txt_preco;
        private Button btn_adicionar;
        private Button btn_editar;
        private Button btn_excluir;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Button btn_pesquisa;
    }
}
