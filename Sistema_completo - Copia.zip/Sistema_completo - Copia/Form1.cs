namespace Sistema_completo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void CarregarTela(UserControl tela)
        {
            panel2.Controls.Clear();
            tela.Dock = DockStyle.Fill;
            panel2.Controls.Add(tela);
        }


        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_minimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void btn_cadastre_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Tela_cadastro tela2 = new Tela_cadastro();
            tela2.Show();
            this.Hide();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Tela_recupera_senha telaSenha = new Tela_recupera_senha();
            telaSenha.Show();


        }

        private void btn_entrar_Click(object sender, EventArgs e)
        {
            string login = txt_login.Text;
            string senha = txt_senha.Text;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(senha))
            {
                MessageBox.Show("Preencha os campos corretamente");
            }
            else
            {
                Usuarios usuario = new Usuarios();

                bool loginSucesso = usuario.Logar(login, senha);

                if (loginSucesso)
                {
                    MessageBox.Show("Login realizado com sucesso!");
                    TelaPrincipal tela = new TelaPrincipal();
                    CarregarTela(tela);

                }
                else
                {
                    MessageBox.Show("Login inv�lido. Verifique o e-mail, nome de usu�rio ou senha.");
                }
            }
        }

    }
}
