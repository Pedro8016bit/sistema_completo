﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_completo
{
    public partial class Tela_recupera_senha : Form
    {
        public Tela_recupera_senha()
        {
            InitializeComponent();
        }

        private void Tela_recupera_senha_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(TxtEmail.Text) || string.IsNullOrWhiteSpace(Txt_novaSenha.Text))
            {
                MessageBox.Show("Preencha os campos corretamente!");
                return;
            }
            else
            {
                Usuarios usuario = new Usuarios();
                usuario.Senha = Txt_novaSenha.Text;
                usuario.Email = TxtEmail.Text;

                bool sucesso = usuario.AlterarSenha(usuario.Email, usuario.Senha);

                if (sucesso)
                {
                    MessageBox.Show("Usuário cadastrado com sucesso!");
                }
                else
                {
                    MessageBox.Show("Erro ao cadastrar usuário.");
                }
            }
        }
    }
}
