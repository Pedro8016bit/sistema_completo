﻿namespace Sistema_completo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            btn_minimizar = new PictureBox();
            btn_fechar = new PictureBox();
            panel2 = new Panel();
            linkLabel1 = new LinkLabel();
            txt_login = new TextBox();
            btn_cadastre = new LinkLabel();
            btn_entrar = new Button();
            label2 = new Label();
            label1 = new Label();
            txt_senha = new TextBox();
            pictureBox3 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btn_minimizar).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btn_fechar).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Navy;
            panel1.Controls.Add(btn_minimizar);
            panel1.Controls.Add(btn_fechar);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(850, 31);
            panel1.TabIndex = 0;
            // 
            // btn_minimizar
            // 
            btn_minimizar.Image = (Image)resources.GetObject("btn_minimizar.Image");
            btn_minimizar.Location = new Point(784, 3);
            btn_minimizar.Name = "btn_minimizar";
            btn_minimizar.Size = new Size(24, 24);
            btn_minimizar.SizeMode = PictureBoxSizeMode.AutoSize;
            btn_minimizar.TabIndex = 1;
            btn_minimizar.TabStop = false;
            btn_minimizar.Click += btn_minimizar_Click;
            // 
            // btn_fechar
            // 
            btn_fechar.Image = (Image)resources.GetObject("btn_fechar.Image");
            btn_fechar.Location = new Point(814, 3);
            btn_fechar.Name = "btn_fechar";
            btn_fechar.Size = new Size(24, 24);
            btn_fechar.SizeMode = PictureBoxSizeMode.AutoSize;
            btn_fechar.TabIndex = 1;
            btn_fechar.TabStop = false;
            btn_fechar.Click += btn_fechar_Click;
            // 
            // panel2
            // 
            panel2.Controls.Add(linkLabel1);
            panel2.Controls.Add(txt_login);
            panel2.Controls.Add(btn_cadastre);
            panel2.Controls.Add(btn_entrar);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(txt_senha);
            panel2.Controls.Add(pictureBox3);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(0, 31);
            panel2.Name = "panel2";
            panel2.Size = new Size(850, 430);
            panel2.TabIndex = 1;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Location = new Point(370, 318);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(105, 15);
            linkLabel1.TabIndex = 5;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Esqueceu a senha?\r\n";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // txt_login
            // 
            txt_login.Location = new Point(306, 175);
            txt_login.MaxLength = 100;
            txt_login.Name = "txt_login";
            txt_login.Size = new Size(227, 23);
            txt_login.TabIndex = 1;
            // 
            // btn_cadastre
            // 
            btn_cadastre.AutoSize = true;
            btn_cadastre.Location = new Point(389, 303);
            btn_cadastre.Name = "btn_cadastre";
            btn_cadastre.Size = new Size(69, 15);
            btn_cadastre.TabIndex = 4;
            btn_cadastre.TabStop = true;
            btn_cadastre.Text = "Cadastre-se";
            btn_cadastre.LinkClicked += btn_cadastre_LinkClicked;
            // 
            // btn_entrar
            // 
            btn_entrar.Location = new Point(369, 277);
            btn_entrar.Name = "btn_entrar";
            btn_entrar.Size = new Size(106, 23);
            btn_entrar.TabIndex = 3;
            btn_entrar.Text = "Entrar";
            btn_entrar.UseVisualStyleBackColor = true;
            btn_entrar.Click += btn_entrar_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(310, 214);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 4;
            label2.Text = "Senha:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(310, 157);
            label1.Name = "label1";
            label1.Size = new Size(84, 15);
            label1.TabIndex = 3;
            label1.Text = "Usuario/Email:";
            // 
            // txt_senha
            // 
            txt_senha.Location = new Point(306, 232);
            txt_senha.MaxLength = 100;
            txt_senha.Name = "txt_senha";
            txt_senha.Size = new Size(227, 23);
            txt_senha.TabIndex = 2;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(385, 74);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(73, 65);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.Zoom;
            ClientSize = new Size(850, 461);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btn_minimizar).EndInit();
            ((System.ComponentModel.ISupportInitialize)btn_fechar).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private PictureBox btn_fechar;
        private PictureBox btn_minimizar;
        private Panel panel2;
        private PictureBox pictureBox3;
        private LinkLabel btn_cadastre;
        private Button btn_entrar;
        private Label label2;
        private Label label1;
        private TextBox txt_senha;
        private TextBox txt_login;
        private LinkLabel linkLabel1;
    }
}
