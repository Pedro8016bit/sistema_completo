namespace Sistema_completo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_minimizar_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void btn_cadastre_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Tela_cadastro tela2 = new Tela_cadastro();
            tela2.Show();
            this.Hide();
        }
    }
}
