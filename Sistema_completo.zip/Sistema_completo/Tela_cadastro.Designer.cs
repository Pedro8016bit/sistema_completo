﻿namespace Sistema_completo
{
    partial class Tela_cadastro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tela_cadastro));
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            btn_Cad = new Button();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txt_cpf = new MaskedTextBox();
            txt_senha = new TextBox();
            txt_email = new TextBox();
            txt_usuario = new TextBox();
            txt_nome = new TextBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Navy;
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(850, 31);
            panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(784, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(24, 24);
            pictureBox2.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(814, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(24, 24);
            pictureBox1.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // btn_Cad
            // 
            btn_Cad.Location = new Point(456, 275);
            btn_Cad.Name = "btn_Cad";
            btn_Cad.Size = new Size(229, 23);
            btn_Cad.TabIndex = 10;
            btn_Cad.Text = "Cadastrar";
            btn_Cad.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(459, 185);
            label5.Name = "label5";
            label5.Size = new Size(42, 15);
            label5.TabIndex = 9;
            label5.Text = "Senha:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(133, 185);
            label4.Name = "label4";
            label4.Size = new Size(50, 15);
            label4.TabIndex = 8;
            label4.Text = "Usuario:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(133, 257);
            label3.Name = "label3";
            label3.Size = new Size(29, 15);
            label3.TabIndex = 7;
            label3.Text = "Cpf:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(459, 112);
            label2.Name = "label2";
            label2.Size = new Size(39, 15);
            label2.TabIndex = 6;
            label2.Text = "Email:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(133, 112);
            label1.Name = "label1";
            label1.Size = new Size(43, 15);
            label1.TabIndex = 5;
            label1.Text = "Nome:";
            // 
            // txt_cpf
            // 
            txt_cpf.Location = new Point(131, 275);
            txt_cpf.Mask = "000.000.000-00";
            txt_cpf.Name = "txt_cpf";
            txt_cpf.Size = new Size(229, 23);
            txt_cpf.TabIndex = 4;
            // 
            // txt_senha
            // 
            txt_senha.Location = new Point(456, 203);
            txt_senha.MaxLength = 100;
            txt_senha.Name = "txt_senha";
            txt_senha.Size = new Size(229, 23);
            txt_senha.TabIndex = 3;
            // 
            // txt_email
            // 
            txt_email.Location = new Point(456, 130);
            txt_email.MaxLength = 100;
            txt_email.Name = "txt_email";
            txt_email.Size = new Size(229, 23);
            txt_email.TabIndex = 2;
            // 
            // txt_usuario
            // 
            txt_usuario.Location = new Point(131, 203);
            txt_usuario.MaxLength = 100;
            txt_usuario.Name = "txt_usuario";
            txt_usuario.Size = new Size(229, 23);
            txt_usuario.TabIndex = 1;
            // 
            // txt_nome
            // 
            txt_nome.Location = new Point(131, 130);
            txt_nome.MaxLength = 100;
            txt_nome.Name = "txt_nome";
            txt_nome.Size = new Size(229, 23);
            txt_nome.TabIndex = 0;
            // 
            // Tela_cadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(850, 461);
            Controls.Add(btn_Cad);
            Controls.Add(txt_senha);
            Controls.Add(label5);
            Controls.Add(panel1);
            Controls.Add(label4);
            Controls.Add(txt_nome);
            Controls.Add(txt_cpf);
            Controls.Add(txt_usuario);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(txt_email);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Tela_cadastro";
            Text = "Tela_cadastro";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private MaskedTextBox txt_cpf;
        private TextBox txt_senha;
        private TextBox txt_email;
        private TextBox txt_usuario;
        private TextBox txt_nome;
        private Button btn_Cad;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
    }
}