﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_completo
{
    class Usuarios
    {
        private string nome;
        private string cpf;
        private string email;
        private string usua;
        private string senha;

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string Cpf
        {
            get { return cpf; }
            set { cpf = value; }
        }
        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string Usua
        {
            get { return usua; }
            set { usua = value; }
        }
        public string Senha
        {
            get { return senha; }
            set { senha = value; }
        }

        public bool CadastrarUser()
        {
            try
            {
                using (MySqlConnection conexaoBanco = new BancoDb().Conectar())
                {
                    string inserir = "insert into usuarios (nome, cpf, email, usua, senha) values (@nome, @cpf, @email, @usua, @senha);";

                    MySqlCommand comando = new MySqlCommand(inserir, conexaoBanco);
                    comando.Parameters.AddWithValue("@nome", Nome);
                    comando.Parameters.AddWithValue("@cpf", Cpf);
                    comando.Parameters.AddWithValue("@email", Email);
                    comando.Parameters.AddWithValue("@usua", Usua);


                    int resultado = comando.ExecuteNonQuery();

                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("erro(na classe ususarios) ao realizar cadastro" + ex.Message);
                return false;
            }
        }
    }
}
